inlets = 2;
outlets = 1;

var set1 = new Array();
var set2 = new Array();
var hyperEuclidSet = new Array();

// all inlets trigger output
function list() {
    if (inlet == 1) {
		set2 = arrayfromargs(arguments);
		bang(set1, set2);
     }
	else {
		set1 = arrayfromargs(arguments);
		bang(set1, set2);
	}
}

function bang(set1, set2) {
	var i;
	var num;
	// do the subtraction here instead of calling a function
	for(i=0; i<set2.length; i++) {
		hyperEuclidSet.push(set1[set2[i]]) ;
	}
	outlet(0, hyperEuclidSet);
	hyperEuclidSet = new Array();
}